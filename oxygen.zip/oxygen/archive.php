<?php
/**
 *    Oxygen WordPress Theme
 *
 *    Laborator.co
 *    www.laborator.co
 */
defined( 'ABSPATH' ) || exit;

// Header
get_header();

// Blog loop template
get_template_part( 'tpls/blog-loop' );

// Footer
get_footer();
