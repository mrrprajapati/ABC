<?php
/**
 *	Oxygen WordPress Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */
defined( 'ABSPATH' ) || exit;

// Header
get_header();

// Show the content.. probably this page will never loaded
the_content();

// Footer
get_footer();
