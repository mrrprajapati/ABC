<?php
/**
 *    Oxygen WordPress Theme
 *
 *    Laborator.co
 *    www.laborator.co
 */

?>
<footer class="footer_widgets">
    <div class="row">

		<?php dynamic_sidebar( 'footer_sidebar' ); ?>

    </div>
</footer>